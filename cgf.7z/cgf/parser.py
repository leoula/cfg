__author__ = 'peace'


def parse():
    infile = open("source.c", "r")
    test = recurse(infile.readlines(), 0)
    expandDict(test)
    print(expandSiblings(test))

def expandDict(lst):
    length = len(lst)
    for i in range(length):
        item = lst[i]
        if type(item) == type({}):
            for key, value in item.items():
                if len(value) == 0:
                    lst[i] = key
                else:
                    size = len(value)
                    for j in range(size):
                        val = value[j]
                        if type(val) == type([]):
                            expandDict(value[j])
                    # expand out
                    expanded = []
                    for val in value:
                        exp = []
                        for v in val:
                            exp.append(key+v)
                        expanded.append(exp)
                    lst[i] = expanded
        else:
            expandDict(lst[i])

def expandSiblings(siblings):
    master = ['']
    length = len(siblings)
    for i in range(length):
        siblings[i] = getRecurList(siblings[i])
        sibling = siblings[i]
        sibling_len = len(sibling)
        master_len = len(master)
        extend_info = []
        for k in range(sibling_len):
            if type(sibling[k]) == type([]):
                extend_info.append({k: expandSiblings(sibling[k])})
        len_info = len(extend_info)
        off = 0
        for r in range(len_info):
            inf = extend_info[r]
            for indx, new_lst in inf.items():
                indx += off
                sibling = sibling[:indx]+new_lst+sibling[indx+1:]
                off += len(new_lst)
        expanded = []
        for j in range(master_len):
            for k in range(sibling_len):
                sibi = sibling[k]
                if type(sibi) == type([]):
                    print(sibi)
                else:
                    expanded.append(master[j]+sibi)
        master = expanded
    return master

def getRecurList(lst):
    while True:
        if type(lst) != type([]):
            return [lst]
        elif type(lst[0]) == type([]):
            lst = lst[0]
        else:
            return lst

def recurse(lines, count):
    nodeCount, siblings = outerIfAndBody(lines, nodeCount=count)
    for sibling in siblings:
        for bro in sibling:
            for index, body in bro.items():
                if len(body ) != 0:
                    ccount, bro[index] = outerIfAndBody(body, nodeCount=nodeCount)
                    recurse(bro[index], ccount)
    return siblings

def outerIfAndBody(lines, nodeCount=0):

    searchStr = ''
    gameOn = False
    curIndex = 0
    length = len(lines)
    huntingElse = False
    paths = []
    sibling = []
    topIfCount = 0
    comingFrom = 0
    linesToAppend = []

    for i in range(length):
        line = str(lines[i]).strip()
        if (not gameOn) and str(line).strip().startswith("if"):
            gameOn = True
            topIfCount = nodeCount + 1
        if gameOn:
            searchStr += line
            linesToAppend.append(line)
            if huntingElse:

                if i == length - 1:
                    appendSibling(comingFrom, sibling, topIfCount, nodeCount, linesToAppend[1:-2], end=True)

                if searchStr.startswith('else if'):
                    appendSibling(comingFrom, sibling, topIfCount, nodeCount, linesToAppend[1:-2])
                    comingFrom = 1
                    huntingElse = False
                    linesToAppend = []
                elif searchStr.startswith('else'):
                    appendSibling(comingFrom, sibling, topIfCount, nodeCount, linesToAppend[1:-2])
                    huntingElse = False
                    comingFrom = 2
                    linesToAppend = []
                elif searchStr.startswith('if'):
                    appendSibling(comingFrom, sibling, topIfCount, nodeCount, linesToAppend[1:-2], end=True)
                    huntingElse = False
                    paths.append(sibling)
                    sibling = []
                    comingFrom = 0
                    topIfCount = nodeCount
                    linesToAppend = []

                else:
                    continue
            # find the index of }
            if str(searchStr).find('}', curIndex, len(searchStr)+1) != -1:
                curIndex = str(searchStr).find('}', curIndex, len(searchStr)+1)+1
                leftCount = str(searchStr)[:curIndex].count('}')
                rightCount = str(searchStr)[:curIndex].count('{')
                if leftCount != 0 and leftCount == rightCount:
                    # we have found the end of the if
                    # bodyToAppend = searchStr[startIndex+1:curIndex-1]
                    searchStr = searchStr[curIndex:].strip()
                    curIndex = 0
                    huntingElse = True
                    nodeCount += 1

    # add the final sibling
    if sibling is not []:
        paths.append(sibling)

    return nodeCount, paths

def appendSibling(comingFrom, sibling, topIfCount, nodeCount, linesToAppend, end=False):
    index = ''
    yeah = False
    for line in linesToAppend:
        if str(line).startswith('if'):
            yeah = True
    linesToAppend = linesToAppend if yeah else []
    if comingFrom == 0:
        index = str(nodeCount)+'T'
        sibling.append({index: linesToAppend})
        if end :
            index = str(nodeCount)+'F'
            sibling.append({index: []})
    elif comingFrom == 1:
        for j in range(topIfCount, nodeCount):
            index += str(j)+'F'
        index += str(nodeCount)+'T'
        sibling.append({index: linesToAppend})
        if end:
            index = ''
            for j in range(topIfCount, nodeCount+1):
                index += str(j)+'F'
            sibling.append({index: []})
    elif comingFrom == 2:
        for j in range(topIfCount, nodeCount):
            index += str(j)+'F'
        sibling.append({index: linesToAppend})
            
parse()
