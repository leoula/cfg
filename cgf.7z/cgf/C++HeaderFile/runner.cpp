#include <iostream>
#include <Student.h>
using namespace std;

int main() {

    Student student("ATR/0337/08");
    student.setFirstName("Mezigebu");
    student.setLastName("Zework");
    student.setDepartment("Software Engineering");
    student.setClassYear("Junior");

    student.displayStudentInfo();
    
}